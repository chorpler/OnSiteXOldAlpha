angular.module('app.routes', [])

.config(function($stateProvider, $urlRouterProvider) {

  // Ionic uses AngularUI Router which uses the concept of states
  // Learn more here: https://github.com/angular-ui/ui-router
  // Set up the various states which the app can be in.
  // Each state's controller can be found in controllers.js
  $stateProvider
    
  

      .state('accountInfo', {
    url: '/account-info',
    templateUrl: 'templates/accountInfo.html',
    controller: 'accountInfoCtrl'
  })

  .state('selectDate', {
    url: '/dateSel',
    templateUrl: 'templates/selectDate.html',
    controller: 'selectDateCtrl'
  })

  .state('workOrderReport', {
    url: '/work-order-form',
    templateUrl: 'templates/workOrderReport.html',
    controller: 'workOrderReportCtrl'
  })

  .state('tECHHome', {
    url: '/tech-home',
    templateUrl: 'templates/tECHHome.html',
    controller: 'tECHHomeCtrl'
  })

  .state('reviewRequests', {
    url: '/rev-reqs',
    templateUrl: 'templates/reviewRequests.html',
    controller: 'reviewRequestsCtrl'
  })

  .state('stats', {
    url: '/stats',
    templateUrl: 'templates/stats.html',
    controller: 'statsCtrl'
  })

  .state('topperReport', {
    url: '/tp-report',
    templateUrl: 'templates/topperReport.html',
    controller: 'topperReportCtrl'
  })

  .state('DdddMmmDdYyyy', {
    url: '/work-day',
    templateUrl: 'templates/DdddMmmDdYyyy.html',
    controller: 'DdddMmmDdYyyyCtrl'
  })

  .state('messageFromTino', {
    url: '/msgTino',
    templateUrl: 'templates/messageFromTino.html',
    controller: 'messageFromTinoCtrl'
  })

  .state('login', {
    url: '/login',
    templateUrl: 'templates/login.html',
    controller: 'loginCtrl'
  })

  .state('shiftTime', {
    url: '//shft-time',
    templateUrl: 'templates/shiftTime.html',
    controller: 'shiftTimeCtrl'
  })

  .state('mECHANICALFIRSTWORD', {
    url: '/m-first-word',
    templateUrl: 'templates/mECHANICALFIRSTWORD.html',
    controller: 'mECHANICALFIRSTWORDCtrl'
  })

  .state('page', {
    url: '/page15',
    templateUrl: 'templates/page.html',
    controller: 'pageCtrl'
  })

$urlRouterProvider.otherwise('/account-info')

  

});